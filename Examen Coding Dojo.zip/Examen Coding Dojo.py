# Importar las bibliotecas necesarias
  
import numpy as np    # Numpy se utiliza para operaciones matemáticas
import pandas as pd   # Pandas se utiliza para la manipulación y análisis de datos
import matplotlib.pyplot as plt  # Matplotlib se utiliza para visualizaciones básicas
import seaborn as sns  # Seaborn  se utiliza para visualizaciones más avanzadas

#El dataset ha sido descargado desde la Página de kaggle. Puedes encontrar el dataset en el siguiente link: https://www.kaggle.com/datasets/arnabchaki/data-science-salaries-2023

# Paso 1: Cargar el dataset desde un archivo local
# ------------------------------------------------------------
# En este paso, cargamos el archivo CSV desde la carpeta donde se encuentra el dataset.
# Supongamos que el archivo está guardado en la carpeta de 'Descargas' de tu computadora.
# Ajusta la ruta del archivo según tu directorio. 
# El método pd.read_csv() se usa para leer archivos CSV.

file_path = r'C:\Users\admin\Downloads\ds_salaries.csv'  # Ajusta esto con la ruta correcta
df = pd.read_csv(file_path)  # Carga el archivo CSV en un DataFrame de pandas

# Ver las primeras 10 filas para asegurarse de que los datos se han cargado correctamente
print("Primeras filas del dataset:")
print(df.head(10))

# Paso 2: Eliminar duplicados
# ------------------------------------------------------------
# Los duplicados en los datos pueden generar sesgos en el análisis.
# El método 'drop_duplicates()' elimina cualquier fila duplicada en el DataFrame.

df.drop_duplicates(inplace=True)  # Elimina filas duplicadas si las hay

# Verificación para comprobar si se han eliminado duplicados correctamente
print(f"Total de filas después de eliminar duplicados: {len(df)}")